// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Destruct phi nodes"); }
int main(){
  announce();
  return lionss_run_workload("ssaDestruct");
}
