// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Decoupled weight decay"); }
int main(){
  announce();
  return lionss_run_workload("adamW-decouple");
}
