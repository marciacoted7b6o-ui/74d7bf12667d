// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode with tiles\n", stdout);
  return lionss_run_workload("hevc_tiles");
}
