// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Benchmark probe sequence\n", stdout);
  return lionss_run_workload("hashbrown-lite");
}
