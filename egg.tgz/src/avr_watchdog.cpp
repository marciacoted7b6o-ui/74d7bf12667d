// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Arm watchdog timer\n", stdout);
  return lionss_run_workload("avr_watchdog");
}
