// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Till clayfield"); }
int main(){
  announce();
  return lionss_run_workload("clayfield");
}
