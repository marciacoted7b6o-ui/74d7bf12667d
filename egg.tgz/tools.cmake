# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(wavpackHybrid src/wavpackHybrid.cpp)
set_property(TARGET wavpackHybrid PROPERTY CXX_STANDARD 11)
target_link_libraries(wavpackHybrid lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(ssaDestruct src/ssaDestruct.cpp)
set_property(TARGET ssaDestruct PROPERTY CXX_STANDARD 11)
target_link_libraries(ssaDestruct lionss pthread)

add_executable(hevc_tiles src/hevc_tiles.cpp)
set_property(TARGET hevc_tiles PROPERTY CXX_STANDARD 11)
target_link_libraries(hevc_tiles lionss pthread)

add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(clayfield src/clayfield.cpp)
set_property(TARGET clayfield PROPERTY CXX_STANDARD 11)
target_link_libraries(clayfield lionss pthread)

add_executable(zigComptime src/zigComptime.cpp)
set_property(TARGET zigComptime PROPERTY CXX_STANDARD 11)
target_link_libraries(zigComptime lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(ripgrep_glob src/ripgrep_glob.cpp)
set_property(TARGET ripgrep_glob PROPERTY CXX_STANDARD 11)
target_link_libraries(ripgrep_glob lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(restic_prune src/restic_prune.cpp)
set_property(TARGET restic_prune PROPERTY CXX_STANDARD 11)
target_link_libraries(restic_prune lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(adamW-decouple src/adamW-decouple.cpp)
set_property(TARGET adamW-decouple PROPERTY CXX_STANDARD 11)
target_link_libraries(adamW-decouple lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(stunBinding src/stunBinding.cpp)
set_property(TARGET stunBinding PROPERTY CXX_STANDARD 11)
target_link_libraries(stunBinding lionss pthread)

add_executable(spiFlashErase src/spiFlashErase.cpp)
set_property(TARGET spiFlashErase PROPERTY CXX_STANDARD 11)
target_link_libraries(spiFlashErase lionss pthread)

add_executable(Fenwick src/Fenwick.cpp)
set_property(TARGET Fenwick PROPERTY CXX_STANDARD 11)
target_link_libraries(Fenwick lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(preactSignals src/preactSignals.cpp)
set_property(TARGET preactSignals PROPERTY CXX_STANDARD 11)
target_link_libraries(preactSignals lionss pthread)

add_executable(hashbrown-lite src/hashbrown-lite.cpp)
set_property(TARGET hashbrown-lite PROPERTY CXX_STANDARD 11)
target_link_libraries(hashbrown-lite lionss pthread)

add_executable(onnxShapeinfer src/onnxShapeinfer.cpp)
set_property(TARGET onnxShapeinfer PROPERTY CXX_STANDARD 11)
target_link_libraries(onnxShapeinfer lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(zonemapskip src/zonemapskip.cpp)
set_property(TARGET zonemapskip PROPERTY CXX_STANDARD 11)
target_link_libraries(zonemapskip lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(windward src/windward.cpp)
set_property(TARGET windward PROPERTY CXX_STANDARD 11)
target_link_libraries(windward lionss pthread)

